//import FuncDemo from "./components/funcDemo";
//import ClassDemo from "./components/classDemo";
//import Room1 from "./components/room1.js";
//import Room2 from "./components/room2.js";
import "./App.css"
import 'bootstrap/dist/css/bootstrap.min.css';
//import ConditionalDemo from "./components/conditionalDemo";
//import LifeCycleDemo from "./components/lifeCycleDemo";
//import UseContext from "./components/useContext";
//import UseMemoDemo from "./components/useMemoDemo";
import {BrowserRouter,   Route, Routes} from "react-router-dom"
import Home from "./routing/home";
import About from "./routing/about";
import ContactUs from "./routing/contactus";
import React,{Navigate,useState } from "react"
import PageNotFound from "./routing/PageNotFound";
import College from "./routing/college";
import Student from "./routing/student";
import Teacher from "./routing/teacher";
import Login from "./components/LoginNew";
import Dashboard from "./routing/Dashboard";
import MapDemo from "./routing/MapDemo";
import Axios from "./routing/Axios";
import Fetch from "./routing/fetch";
import FormDemo from "./routing/FormDemo";
import UnControlled from "./routing/UnControlled";
import Controlled from "./routing/Controlled";
import TabsExample from "./routing/TabsExample";
import ManageItem from "./routing/ManageItem";
import Material from "./routing/Material";
import Counter from "./redux/Counter";
import Register from "./routing/Register";
import ProductList from './components/ProductList';
import Cart from './components/Cart';
import Checkout from './components/Checkout';

export default function App() {
    const [products] = useState([
        { id: 1, name: 'Product 1', description: 'Description 1', price: 100 },
        { id: 2, name: 'Product 2', description: 'Description 2', price: 200 },
    ]);
    const [cart, setCart] = useState([]);

    const addToCart = product => {
        setCart([...cart, { ...product, quantity: 1 }]);
    };

    return (
            <div className="container">

                <BrowserRouter>
                    <Routes>
                        <Route path="/" element={<Login />} />
                        <Route path="/" element={<Navigate replace to ="/login" /> } />

                        <Route path="/dashboard" element={<Dashboard />} >
                            <Route path="home" element={<Home />} />
                            <Route path="about" element={<About />} />
                            <Route path="contactus" element={<ContactUs />} />
                            <Route path="college" element={<College />} >
                                <Route path="student" element={<Student />} />
                                <Route path="teacher" element={<Teacher />} />
                            </Route>
                            <Route path="axios" element={<Axios />} />
                            <Route path="fetch" element={<Fetch />} />
                            <Route path="formdemo" element={<FormDemo />} />
                            <Route path="map" element={<MapDemo />} />
                            <Route path="uncontrolled" element={<UnControlled />} />
                            <Route path="controlled" element={<Controlled />} />
                            <Route path="tabsexample" element={<TabsExample />} />
                            <Route path="manageitem" element={<ManageItem />} />
                            <Route path="counter" element={<Counter />} />
                            <Route path="material" element={<Material />} />
                            <Route path="register" element={<Register />} />
                            <Route path="products" element={<ProductList products={products} addToCart={addToCart} />} />
                            <Route path="cart" element={ <Cart cartItems={cart}  />} />
                            <Route path="checkout" element={ <Checkout />} />
                        </Route>
                        <Route path="*" element={<PageNotFound />} />
                    </Routes>
                </BrowserRouter>

            </div>

        );
}

