import React,{Component} from "react"
export default class Room2 extends Component {
constructor(){
super();

this.state = {
    carPrice:5000,
    carSpeed:500,
    bikePrice:3000,
    bikeSpeed:100
    }
}
render() {
return <div>
    <button onClick={()=>this.setState({carPrice:10000})} >Change Car Price</button>
    <button onClick={()=>this.setState({carSpeed:1000})} >Change Car Speed</button>
    <button onClick={()=>this.setState({bikePrice:6000})} >Change Bike Price</button>
    <button onClick={()=>this.setState({bikeSpeed:200})} >Change Bike Speed</button>
    <br/> Car Price are ' {this.state.carPrice}
    <br/> Car Speed are ' {this.state.carSpeed}
    <br/> Bike Price are ' {this.state.bikePrice}
    <br/> Bike Speed are ' {this.state.bikeSpeed}
</div>;
}
}