import React,{useState} from "react"

export default function Room1(props){
const [carPrice, setCarPrice] = useState(5000);
const [carSpeed, setCarSpeed] = useState(500);
const [bikePrice, setBikePrice] = useState(3000);
const [bikeSpeed, setBikeSpeed] = useState(100);
return <div>

    <button onClick={()=>setCarPrice(10000)} >Change Car Price</button>
    <button onClick={()=>setCarSpeed(1000)} >Change Car Speed</button>
    <button onClick={()=>setBikePrice(6000)} >Change Bike Price</button>
    <button onClick={()=>setBikeSpeed(200)} >Change Bike Speed</button>
    <br/> Car Price are ' {carPrice}
    <br/> Car Speed are ' {carSpeed}
    <br/> Bike Price are ' {bikePrice}
    <br/> Bike Speed are ' {bikeSpeed}
</div>
}