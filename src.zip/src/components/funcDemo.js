import React,{useState} from "react"

export default function FuncDemo(props){
    const [val, setVal] = useState(10);
    return <div>
        This is Functional Demo {props.name}- {props.age}
        <br/>
        <button onClick={()=>setVal(25)} >Change Val</button>
        <br/> States are ' {val}</div>
}