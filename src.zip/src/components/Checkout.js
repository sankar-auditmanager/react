import React from 'react';

const Checkout = () => {
    return (
        <div>
            <h2>Checkout</h2>
            <p>Checkout form goes here</p>
        </div>
    );
};

export default Checkout;