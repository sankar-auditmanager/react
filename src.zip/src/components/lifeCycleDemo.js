import React,{Component} from "react"
export default class LifeCycleDemo extends Component {
    constructor(){
        super();
        this.state = {data:200};

    }
   // static getDerivedStateFromProps(props,state){
       // return {data: props.color};
   // }
    componentDidMount() {
        alert('component loaded')
    }npmnmount() {
        alert('comp going to unmount');
    }

    getSnapshotBeforeUpdate(prevProps, prevState) {
        console.log('get Snapshot before update prePropos='+prevProps.data)
        console.log('get Snapshot before update preState='+prevState.data)
    }
    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log('componentDidUpdate  prePropos='+prevProps.data)
        console.log('componentDidUpdate  preState='+prevState.data)
        console.log('componentDidUpdate snapshot='+snapshot)

    }
    shouldComponentUpdate(nextProps, nextState, nextContext) {
        console.log('shouldComponentUpdate  nextProps='+nextProps.data)
        console.log('shouldComponentUpdate  nextState='+nextState.data)
        console.log('shouldComponentUpdate  nextContext='+nextContext.data)
        return true;
    }

    render() {

            return <div>This is Life Cycle Demo
                <br/>
                <button onClick={() => this.setState({data: 'Red'})}>Change Data</button>
                <br/>
                States are - {this.state.data}<br/>
            </div>

    }
}
