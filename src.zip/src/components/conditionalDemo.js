import React,{useState} from "react"

export default function ConditionalDemo(props){
    const [show, setShow] = useState(true);
    return <div>
        This is Conditional Demo
        <br/>
        <button onClick={()=>setShow(false)} >Change Val</button>
        <br/> {show?'Hello User':'Hello User false'}</div>
}