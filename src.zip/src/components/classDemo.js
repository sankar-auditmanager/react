import React,{Component} from "react"
export default class ClassDemo extends Component {
    constructor(){
        super();
        this.state = {data:200};
    }
    render() {
        return <div>This is Class Demo {this.props.state}- {this.props.district}
            <br/>
            <button onClick={()=>this.setState({data:230})} value={'Change Val'} >Change Val</button>
        <br/>
            States are - {this.state.data}
        </div>;
    }
}