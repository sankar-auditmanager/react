import React, {useState,useMemo} from "react"
const UseMemoDemo = () => {
    const [count, setCount] = useState(0);
    const [data, setData] = useState(20);
    const expensivecalc = useMemo(() => {
        console.log('calculating.....');
        let result = 0
        for (let i = 0; i < count * 1000000; i++) {
            result += 1;
        }
        return result;
    }, [count]);
    return (
        <div>
            <h1>useMemo Example</h1>
            <p>Count: {count}</p>
            <br/>
            <button onClick={() => setCount(count + 1)}>Increment Count</button>
            <br/>
            <p>Data: {data}</p>
            <button onClick={() => setData(data + 1)}>Increment Data</button>
            <p>Resule Calculation : {expensivecalc}</p>
        </div>
    );
};
export default UseMemoDemo;