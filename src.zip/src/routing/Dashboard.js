import React from "react";
import {NavLink, Outlet} from "react-router-dom";

export default function Dashboard (){
    return (
        <>
        <ul>
            <li>
                <NavLink to="/">Home</NavLink>
            </li>
            <li>
                <NavLink to="about">About</NavLink>
            </li>
            <li>
                <NavLink to="contactus">Contactus</NavLink>
            </li>
            <li>
            <NavLink to="college">College</NavLink>
            </li>
            <li>
                <NavLink to="axios">Axios</NavLink>
            </li>
            <li>
                <NavLink to="fetch">Fetch</NavLink>
            </li>
            <li>
                <NavLink to="formdemo">Forms</NavLink>
            </li>
            <li>
                <NavLink to="controlled">Controlled</NavLink>
            </li>
            <li>
                <NavLink to="uncontrolled">UNControlled</NavLink>
            </li>
            <li>
                <NavLink to="tabsexample">TabsExample</NavLink>
            </li>
            <li>
                <NavLink to="manageitem">Manage Add/Edit/Delete</NavLink>
            </li>
            <li>
                <NavLink to="counter">Counter</NavLink>
            </li>
            <li>
                <NavLink to="material">Material</NavLink>
            </li>
            <li>
                <NavLink to="products">Products</NavLink>
            </li>
            <li>
                <NavLink to="cart">Cart</NavLink>
            </li>
            <li>
                <NavLink to="checkout">Checkout</NavLink>
            </li>
            <li>
                <NavLink to="/" className="logoutTab">Logout</NavLink>
            </li>
        </ul>
            <Outlet/>
        </>
    )
}
