import React, { useRef } from "react";
export default function UnControlled() {
    const inputRef = useRef(null);
    const emailRef = useRef(null);

    function handleSubmit() {
        alert(`Name: ${inputRef.current.value}`);
        alert(`Email: ${emailRef.current.value}`);
    }

    return (
        <div className="App">
            <h1 className="geeks">GeeksForGeeks</h1>
            <h3>Uncontrolled Component</h3>
            <form onSubmit={handleSubmit}>
                <label>Name :</label>
                <input
                    type="text"
                    name="name"
                    ref={inputRef}
                />
                <input
                    type="text"
                    name="email"
                    ref={emailRef}
                />
                <button type="submit">Submit</button>
            </form>
        </div>
    );
}