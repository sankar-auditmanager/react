import React,{useEffect,useState} from "react";
export default function Fetch (){
    const [apidata,setApiData] = useState([]);

    useEffect(() => {
        fetch("https://reqres.in/api/users?page=1")
            .then(response => response.json())
            .then(data => setApiData(data.data))
            .catch(error => console.error('Error fetching data:', error));
    }, []);

    return <div><table border="1"><tr>
        <th>Sno</th><th>Image</th><th>Name</th><th>Email ID</th>
    </tr>
        {apidata.map((user,index) => (
            <tr><td>{index+1}</td><td><img key={user.id} src={user.avatar} alt={user.avatar} width={100} /></td><td>{user.last_name} {user.first_name}</td><td>{user.email}</td>
            </tr>
        ))}
    </table>
    </div>;
}
