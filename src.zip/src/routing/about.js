import React from "react"
export default function About(){
    return <di>This is About Compoenent</di>
}