import React, { useState } from "react";

export default function Counter()  {
    const [counter, setCounter] = useState(10);
    const handleClick1 = () => {
        setCounter(counter + 1);
    };
    const handleClick2 = () => {
        setCounter(counter - 1);
    };
    return (
        <div>
            Counter
            <div>
                {counter}
            </div>
            <div className="buttons">
                <button onClick={handleClick1}>Increment</button>
                <button disabled={counter === 0} onClick={handleClick2} > Decrement </button>
            </div>
        </div>
    );
};