import React from 'react';
const ItemList = ({ items, deleteItem, editItem }) => {
    return (
        <>
    <div><table border="1"><tr>
        <th>Sno</th><th>Image</th><th>Name</th><th>Email ID</th><th>Action</th>
    </tr>
        {items.map((user,index) => (
            <tr>
                <td>{index+1}</td>
                <td><img key={user.id} src={user.avatar} alt={user.avatar} width={100} /></td>
                <td>{user.last_name} {user.first_name}</td>
                <td>{user.email}</td>
                <td>
                    <button onClick={() => editItem(user)}>Edit</button>
                    <button onClick={() => deleteItem(user.id)}>Delete</button>

                </td>
            </tr>
        ))}
    </table>
    </div>
        </>
    );
};

export default ItemList;