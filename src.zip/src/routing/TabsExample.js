// Filename - App.js

import React from "react";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';

export default function TabsExample() {
    return (
        <>
            <h1 style={{ color: 'green',
                margin: '20px' }}>Nested Tabs</h1>
            <Tabs style={{ width: '500px' }}>
                <TabList style={{
                    fontSize: '20px',
                    margin: '20px',
                    color: "#1616b7",
                    borderRadius: '10px',
                }}>
                    <Tab style={{ background: '#a7f8a2',
                        borderRadius: '5px' }}>Tab 1</Tab>
                    <Tab style={{ background: '#f4faa0',
                        borderRadius: '5px' }}>Tab 2</Tab>
                </TabList>
                <TabPanel style={{ fontSize: '20px',
                    margin: '20px' }}>
                    <Tabs defaultIndex={1}>
                        <TabList>
                            <Tab style={{ background: '#f5e5f8',
                                borderRadius: '5px' }}>Nested-Tab1</Tab>
                            <Tab style={{ background: '#f2f9a0',
                                borderRadius: '5px' }}>Nested-Tab2</Tab>
                            <Tab style={{ background: '#f5e5f8',
                                borderRadius: '5px' }}>Nested-Tab3</Tab>
                        </TabList>
                        <TabPanel>
                            <p style={{ color: 'green' }}>
                               Nested Tab1 Tab1</p>

                        </TabPanel>
                        <TabPanel>
                            <p style={{ color: 'green' }}>
                               Nested Tab1 Tab2.</p>

                        </TabPanel>
                        <TabPanel>
                            <p style={{ color: 'green' }}>
                                Nested Tab1 Tab3</p>

                        </TabPanel>
                    </Tabs>
                </TabPanel>
                <TabPanel style={{ fontSize: '20px',
                    margin: '20px' }}>
                    <Tabs>
                        <TabList>
                            <Tab style={{ background: '#f5e5f8',
                                borderRadius: '5px' }}>Nested-Tab_1</Tab>
                            <Tab style={{ background: '#f2f9a0',
                                borderRadius: '5px' }}>Nested-Tab_2</Tab>
                            <Tab style={{ background: '#f5e5f8',
                                borderRadius: '5px' }}>Nested-Tab_3</Tab>
                        </TabList>
                        <TabPanel>
                            <p style={{ color: 'blue' }}>
                               Nested Tab_2 Tab1</p>

                        </TabPanel>
                        <TabPanel>
                            <p style={{ color: 'blue' }}>
                                Nested Tab_2 Tab2.</p>

                        </TabPanel>
                        <TabPanel>
                            <p style={{ color: 'blue' }}>
                                Nested Tab_2 Tab 3</p>

                        </TabPanel>
                    </Tabs>
                </TabPanel>
            </Tabs>
        </>
    );
}
