import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ItemForm from './ItemForm';
import ItemList from './ItemList';
export default function ManageItem() {
    const [items, setItems] = useState([]);
    const [editingItem, setEditingItem] = useState(null);

    useEffect(() => {
        axios.get('https://reqres.in/api/users?page=1')
            .then(response => setItems(response.data.data))
            .catch(error => console.error(error));
    }, []);

    const addItem = (item) => {
        axios.post('https://reqres.in/api/users', item)
            .then(response => setItems([...items.data, response]))
            .catch(error => console.error(error));
    };

    const updateItem = (item) => {
        axios.put(`https://reqres.in/api/users/${item.id}`, item)
            .then(response => {
                setItems(items.map(it => (it.id === item.id ? response.data : it)));
                setEditingItem(null);
            })
            .catch(error => console.error(error));
    };

    const deleteItem = (id) => {
        axios.delete(`https://reqres.in/api/users/${id}`)
            .then(() => setItems(items.filter(item => item.id !== id)))
            .catch(error => console.error(error));
    };

    const editItem = (item) => {
        setEditingItem(item);
    };

    return (
        <div className="App">
            <h1>React CRUD App</h1>
            <ItemForm addItem={addItem} updateItem={updateItem} editingItem={editingItem} />
            <ItemList items={items} deleteItem={deleteItem} editItem={editItem} />
        </div>
    );
};
