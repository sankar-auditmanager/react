import React from "react";
export default function MapDemo (){
    let cars = [
        {
            "color": "purple",
            "type": "minivan",
            "registration": new Date('2017-01-03'),
            "capacity": 7
        },
        {
            "color": "red",
            "type": "station wagon",
            "registration": new Date('2018-03-03'),
            "capacity": 5
        }];
    return (
        <div>
            This is MapDemo Component
            <br/>
            {cars.map((car,index)=>{
                return <p key={index}>
                    {index+1}. {car.color} {car.type} which have a capacity of {car.capacity} registered on {car.registration.toDateString()}</p>
            })
            }
        </div>
    );
}