import React, {useState} from 'react';
import { TextField, Button, Container, Stack } from '@mui/material';
import { Link } from "react-router-dom"
import { Formik, Form, Field, ErrorMessage } from 'formik';

const RegisterForm = () => {
    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [email, setEmail] = useState('')
    const [dateOfBirth, setDateOfBirth] = useState('')
    const [password, setPassword] = useState('')


    return (
        <React.Fragment>
            <h2>Register Form</h2>
            <Formik
                initialValues={{ email: '', password: '' }}
                validate={values => {
                    const errors = {};
                    if (!values.email) {
                        errors.email = 'Required';
                    } else if (
                        !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
                    ) {
                        errors.email = 'Invalid email address';
                    }
                    return errors;
                }}
                onSubmit={(values, { setSubmitting }) => {
                    setTimeout(() => {
                        alert(JSON.stringify(values, null, 2));
                        setSubmitting(false);
                    }, 400);
                }}
            >
                {({ isSubmitting }) => (
            <Form action={<Link to="/login" />}>
                <Stack spacing={2} direction="row" sx={{marginBottom: 4}}>
                    <Field type="text" name="firstname" />
                    <ErrorMessage name="firstname" component="div" />
                    <Field type="text" name="lastname" />
                    <ErrorMessage name="lastname" component="div" />
                </Stack>
                <Stack spacing={2} direction="row" sx={{marginBottom: 4}}>
                <Field type="email" name="email" />
                <ErrorMessage name="email" component="div" />
                <Field type="password" name="password" />
                <ErrorMessage name="password" component="div" />
                </Stack>
                <Stack spacing={2} direction="row" sx={{marginBottom: 4}}>
                <Field type="date" name="dateofbirth" />
                <ErrorMessage name="dateofbirth" component="div" />
                <button type="submit" disabled={isSubmitting}>
                    Register
                </button>
                </Stack>
            </Form>
                )}
            </Formik>
            <small>Already have an account? <Link to="/dashboard/material">Login Here</Link></small>

        </React.Fragment>
    )
}

export default RegisterForm;