import React from "react"
export default function Student(){
    return <div>This is Student Compoenent</div>
}