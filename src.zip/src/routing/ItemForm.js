import React, { useState, useEffect } from 'react';

const ItemForm = ({ addItem, updateItem, editingItem }) => {
    const [item, setItem] = useState({ id: '', first_name: '',last_name: '',avatar:'',email:'' });

    useEffect(() => {
        if (editingItem) {
            setItem(editingItem);
        } else {
            setItem({ id: '', first_name: '' , last_name: '' , avatar: '' , email: '' });
        }
    }, [editingItem]);

    const handleChange = (e) => {
        setItem({ ...item, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (item.id) {
            updateItem(item);
        } else {
            addItem({ ...item, id: Date.now().toString() });
        }
        console.log(item)

    };

    return (
        <form onSubmit={handleSubmit}>
            First Name: <input
                type="text"
                name="first_name"
                value={item.first_name}
                onChange={handleChange}
                placeholder="Enter First name"
                required
            />
            Last Name: <input
                type="text"
                name="last_name"
                value={item.last_name}
                onChange={handleChange}
                placeholder="Enter Last name"
                required
            />
            Email: <input
            type="text"
            name="email"
            value={item.email}
            onChange={handleChange}
            placeholder="Enter email name"
            required
        />
            Image: <input
            type="text"
            name="avatar"
            value={item.avatar}
            onChange={handleChange}
            placeholder="Enter image name"
            required
        />


            <button type="submit">{item.id ? 'Update' : 'Add'}</button>
        </form>
    );
};

export default ItemForm;